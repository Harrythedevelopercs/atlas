<section class="home-sec-08">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="text text-center">
                    <h6>Enough from Us</h6>
                    <h2>See What Our Clients Have to Say</h2>
                    <p>We can go on and on about our services, but if you seek further credibility, then see what our clients have to say about us:</p>
                </div>
                <div class="trust-slider-main trustpilotslider">
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                    <div class="trust-slider-box">
                        <img src="assets/images/trustpilot.webp" alt="">
                        <img src="assets/images/ratingimg.webp" alt="">
                        <h6>Evain Stavenger</h6>
                        <p>“Atlas Publishing Group is a beacon for any aspiring author. Their ghostwriting service breathed life into my ideas, and the book marketing strategies they employed were ingenious. A shoutout to Dennis for being an incredible support!”</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>