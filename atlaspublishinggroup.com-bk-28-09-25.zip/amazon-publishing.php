<!doctype html>
<html lang="en">

<head>
    <?php include 'include/style.php'; ?>
    <title>Amazon Publishing Services Company | Atlas Publishing Group</title>
    <meta name="description" content="">
</head>

<body>
    <?php include 'include/header.php'; ?>
    <section class="herobanner form-banner coverbannerbg">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="text">
                        <h1>Amazon Publishing Services Company To Make Your Book Available To Millions Of Readers!</h1>
                        <div class="two-btn-align">
                            <a href="javascript:void(0)" class="btn t-btn " data-toggle="modal"
                                data-target="#exampleModalCenter">Connect with Us!</a>
                            <a href="tel:<?php echo $phone;?>" class="btn t-btn ">Call us NOW!</a>
                        </div>
                        <div class="counter-boxes">
                            <div class="counter box">
                                <img src="assets/images/counterimg02.png" alt="">
                                <div class="counter">
                                    <h5>400</h5>
                                    <h6>Million Words</h6>
                                </div>
                            </div>
                            <div class="counter box">
                                <img src="assets/images/counterimg03.png" alt="">
                                <div class="counter">
                                    <h5>100</h5>
                                    <h6>Authors</h6>
                                </div>
                            </div>
                            <div class="counter box">
                                <img src="assets/images/counterimg01.png" alt="">
                                <div class="counter">
                                    <h5>870</h5>
                                    <h6>Cups Of Coffee</h6>
                                </div>
                            </div>
                        </div>
                        <img src="assets/images/bannerlogoimages.webp" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <?php include("include/form.php"); ?>
                </div>
            </div>
        </div>
    </section>
    <section class="bannerdownslider">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="downslider">
                        <div class="logoslider">
                            <img src="assets/images/bannersliderlogo01.png" alt="">
                            <img src="assets/images/bannersliderlogo02.png" alt="">
                            <img src="assets/images/bannersliderlogo03.png" alt="">
                            <img src="assets/images/bannersliderlogo04.png" alt="">
                            <img src="assets/images/bannersliderlogo05.png" alt="">
                            <img src="assets/images/bannersliderlogo06.png" alt="">
                            <img src="assets/images/bannersliderlogo07.png" alt="">
                            <img src="assets/images/bannersliderlogo08.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="home-sec-01">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text">
                        <h2>Top-Notch Amazon Self Publishing Services</h2>
                        <p>Let our publishing pros make your books rock on amazon!</p>
                        <span class="divider"></span>
                    </div>
                    <div class="productsimages">
                        <img src="assets/images/productsimages01.webp" alt="">
                        <img src="assets/images/productsimages02.webp" alt="">
                        <img src="assets/images/productsimages03.webp" alt="">
                        <img src="assets/images/productsimages04.webp" alt="">
                    </div>
                    <div class="two-btn-align">
                        <a href="javascript:void(0)" class="btn t-btn" data-toggle="modal"
                            data-target="#exampleModalCenter">Connect with Us!</a>
                        <a href="tel:<?php echo $phone;?>" class="btn t-btn">Call us NOW!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="home-sec-03">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text">
                        <h4>Be a Part of the Best Sellers’ Fraternity</h4>
                        <h2>Some Questions Whirling Around Your Mind About <br>Amazon KDP Publishing Have Answers Over
                            Here!</h2>
                    </div>
                    <div class="numberlist-box">
                        <div class="numberbox">
                            <div class="listnumber">
                                <p>1.</p>
                            </div>
                            <div class="listtext">
                                <h4>What is Amazon KDP?</h4>
                                <p>A professional book publishing service will handle all the technical aspects of
                                    creating and formatting your book, so you can focus on writing.Amazon KDP is a self
                                    publishing service from Amazon that allows authors to publish and distribute their
                                    books worldwide. It's a fast, easy and affordable way to get your book into the
                                    hands of readers looking for new titles to enjoy.</p>
                            </div>
                        </div>
                        <div class="numberbox">
                            <div class="listnumber">
                                <p>2.</p>
                            </div>
                            <div class="listtext">
                                <h4>How Does Amazon KDP Work?</h4>
                                <p>Amazon KDP works by allowing authors to upload their book files to the Amazon Kindle
                                    Store, where they can be sold and downloaded by readers. Authors can also choose to
                                    have their books printed and shipped to customers via Amazon's CreateSpace service.
                                </p>
                            </div>
                        </div>
                        <div class="numberbox">
                            <div class="listnumber">
                                <p>3.</p>
                            </div>
                            <div class="listtext">
                                <h4>How Much Does It Cost To Publish With Amazon KDP?</h4>
                                <p>It costs nothing to publish your book with Amazon KDP. You will only be charged when
                                    your book is sold, and you will receive a 70% royalty on each sale.</p>
                            </div>
                        </div>
                        <div class="numberbox">
                            <div class="listnumber">
                                <p>4.</p>
                            </div>
                            <div class="listtext">
                                <h4>What Are The Requirements For My Book?</h4>
                                <p>Your book must be at least 20 pages long and have a professional cover design.
                                    Additionally, your book must be formatted correctly to be accepted into the Amazon
                                    Kindle Store.</p>
                            </div>
                        </div>
                        <div class="numberbox">
                            <div class="listnumber">
                                <p>5.</p>
                            </div>
                            <div class="listtext">
                                <h4>What Are The Benefits Of Publishing With Amazon KDP?</h4>
                                <p>It costs nothing to publish your book with Amazon KDP. You will only be charged when
                                    your book is sold, and you will receive a 70% royalty on each sale.</p>
                            </div>
                        </div>
                    </div>
                    <div class="two-btn-align">
                        <a href="javascript:void(0)" class="btn t-btn" data-toggle="modal"
                            data-target="#exampleModalCenter">Connect with Us!</a>
                        <a href="tel:<?php echo $phone;?>" class="btn t-btn">Call us NOW!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="home-sec-04" style="background-image:url(assets/images/home-sec04bg.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text">
                        <p>Enlist Yourself with the All-Time Best</p>
                        <h2>our Book Deserves Only The</h2>
                        <h2><span>Atlas Publishing Group.</span></h2>
                    </div>
                    <div class="two-btn-align">
                        <a href="javascript:void(0)" class="btn t-btn" data-toggle="modal"
                            data-target="#exampleModalCenter">Connect with Us!</a>
                        <a href="tel:<?php echo $phone;?>" class="btn t-btn">Call us NOW!</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="home-sec-07">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="text">
                        <h2>Amazon Ebook Publishing To Help Your Work Be A Cut Above The Rest!</h2>
                        <p>Amazon eBook publishing is a great way to get your work out without spending much money. If
                            you're looking for a company that can help you publish your Amazon eBook, look no further
                            than us! We have the experience and expertise to get your book onto Kindle and into the
                            hands of readers worldwide. We know the ins and outs of the Amazon digital book publishing
                            process and can help you navigate it successfully. We'll work with you to format and convert
                            your book, design a professional cover, and create an engaging description. We'll also help
                            you price your book competitively and promote it effectively. And, of course, we'll take
                            care of all the technical details involved in getting your book published on Amazon. If
                            you're ready to take your eBook publishing dreams to the next level, contact us today! We'll
                            be happy to answer any of your questions and get you started on the path to Amazon success
                            owing to our amazon publishing services!</p>
                        <div class="two-btn-align">
                            <a href="javascript:void(0)" class="btn t-btn" data-toggle="modal"
                                data-target="#exampleModalCenter">Connect with Us!</a>
                            <a href="tel:<?php echo $phone;?>" class="btn t-btn">Call us NOW!</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="assets/images/sec05img.webp" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <img src="assets/images/img01.webp" alt="" class="pt-4 pb-4">
            </div>
        </div>
    </div>
    <section class="home-sec-02 about-sec-05">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="text">
                        <h2><span>Don’t Hesitate To Contact Us!</span><br> Start Your Bestseller <br>Journey—Publish
                            With Us Today!</h2>
                        <p>For personalized support or inquiries, our dedicated team is available to assist you during
                            business hours. We warmly invite you to connect with us; your questions and needs are always
                            our priority. Don't hesitate to reach out.</p>
                        <div class="two-btn-align">
                            <a href="#" class="btn t-btn">Start Your Project Today!</a>
                            <a href="javascript:void(0)" class="btn t-btn" data-toggle="modal"
                                data-target="#exampleModalCenter">Connect with Us!</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <section class="scroll-gallery">
                            <div class="scroll-wrapper">
                                <div class="image-col" data-direction="up">
                                    <img src="assets/images/scroll-slider-01.webp" alt="">
                                    <img src="assets/images/scroll-slider-02.webp" alt="">
                                    <img src="assets/images/scroll-slider-03.webp" alt="">
                                    <img src="assets/images/scroll-slider-01.webp" alt="">
                                    <img src="assets/images/scroll-slider-02.webp" alt="">
                                    <img src="assets/images/scroll-slider-03.webp" alt="">
                                    <img src="assets/images/scroll-slider-01.webp" alt="">
                                    <img src="assets/images/scroll-slider-02.webp" alt="">
                                    <img src="assets/images/scroll-slider-03.webp" alt="">
                                    <img src="assets/images/scroll-slider-01.webp" alt="">
                                    <img src="assets/images/scroll-slider-02.webp" alt="">
                                    <img src="assets/images/scroll-slider-03.webp" alt="">
                                </div>
                            </div>
                            <div class="scroll-wrapper ">
                                <div class="image-col center-col" data-direction="down">
                                    <img src="assets/images/scroll-slider-04.webp" alt="">
                                    <img src="assets/images/scroll-slider-05.webp" alt="">
                                    <img src="assets/images/scroll-slider-06.webp" alt="">
                                    <img src="assets/images/scroll-slider-04.webp" alt="">
                                    <img src="assets/images/scroll-slider-05.webp" alt="">
                                    <img src="assets/images/scroll-slider-06.webp" alt="">
                                    <img src="assets/images/scroll-slider-04.webp" alt="">
                                    <img src="assets/images/scroll-slider-05.webp" alt="">
                                    <img src="assets/images/scroll-slider-06.webp" alt="">
                                    <img src="assets/images/scroll-slider-04.webp" alt="">
                                    <img src="assets/images/scroll-slider-05.webp" alt="">
                                    <img src="assets/images/scroll-slider-06.webp" alt="">
                                </div>
                            </div>
                            <div class="scroll-wrapper">
                                <div class="image-col" data-direction="up">
                                    <img src="assets/images/scroll-slider-07.webp" alt="">
                                    <img src="assets/images/scroll-slider-08.webp" alt="">
                                    <img src="assets/images/scroll-slider-09.webp" alt="">
                                    <img src="assets/images/scroll-slider-07.webp" alt="">
                                    <img src="assets/images/scroll-slider-08.webp" alt="">
                                    <img src="assets/images/scroll-slider-09.webp" alt="">
                                    <img src="assets/images/scroll-slider-07.webp" alt="">
                                    <img src="assets/images/scroll-slider-08.webp" alt="">
                                    <img src="assets/images/scroll-slider-09.webp" alt="">
                                    <img src="assets/images/scroll-slider-07.webp" alt="">
                                    <img src="assets/images/scroll-slider-08.webp" alt="">
                                    <img src="assets/images/scroll-slider-09.webp" alt="">
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="home-sec-09" style="background-image:url(assets/images/home-sec09bg.png);">
        <div class="container">
            <div class="row align-items-end">
                <div class="col-lg-7">
                    <div class="text">
                        <h6>No Matter What Choice You Make…</h6>
                        <h2>We Will Always Be Here</h2>
                        <p>We value your time and energy, which is why we're here to help you transform your
                            <br>narrative into a beautifully written book.</p>
                    </div>
                    <div class="down-content">
                        <img src="assets/images/text-imagelast.webp" alt="">
                        <div class="text">
                            <h6>It's Time to Write Your Book!</h6>
                            <p>Now that you have an expert book editing, and publishing agency. What are you waiting
                                for?</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="form-box">
                        <?php include("include/form.php"); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include 'include/footer.php'; ?>