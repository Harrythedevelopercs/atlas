$(document).ready(function () {
    var currentURL = window.location.href;
    var currentIP = $("meta[name=ip2loc]").attr('content');
    $.ajax({
        type: "POST",
        url: "/order/visitor_log.php",
        data: {
            page_url: currentURL,
            client_ip: currentIP
        },
        dataType: "json",
        success: function (response) {
            console.log(response);
        }
    });
    $(".menu-bottom").on("click", function () {
        $("html").toggleClass("menu-open")
    });
    $(".menu-bottom").click(function () {
        $(this).toggleClass("click")
    });
    AOS.init({
        disable: 'mobile'
    });
    $(".validate-popupform").validate();
    $(".app_contact_form").validate();
    $(".validate-autopopupform").validate({});
    var currentIP = $("meta[name=ip2loc]").attr('content');
    var key = '5XpThOAEkfgOvEJ';
    $.ajax({
        method: 'get',
        url: 'https://pro.ip-api.com/json/' + currentIP,
        data: {
            key: key
        },
        success: function (data) {
            if (data) {
                $('input[name=ip2loc_ip]').val(data.query);
                $('input[name=ip2loc_isp]').val(data.isp);
                $('input[name=ip2loc_org]').val(data.org);
                $('input[name=ip2loc_country]').val(data.country);
                $('input[name=ip2loc_region]').val(data.regionName);
                $('input[name=ip2loc_city]').val(data.city);
            }
        }
    });
    $('.lazy').lazy();
    $('.owl-testimonial').owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        margin: 20,
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 8000,
        autoplaySpeed: 800,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 3,
            },
            360: {
                items: 1
            }
        }
    });
    $('.owl-book').owlCarousel({
        loop: true,
        nav: true,
        dots: false,
        margin: 10,
        responsiveClass: true,
        autoplay: true,
        autoplayHoverPause: true,
        autoplayTimeout: 8000,
        autoplaySpeed: 800,
        navigation: true,
        navigationText: ["<img src='http://localhost/assets/images/prev.png'>", "<img src='../../localhost/assets/images/next.png'>"],
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 1,
            },
            360: {
                items: 1,
            }
        }
    });
});
$('.logo-slider .owl-carousel').owlCarousel({
    items: 5,
    loop: true,
    margin: 10,
    autoplay: true,
    nav: false,
    dots: false,
    autoplayTimeout: 1500,
    responsive: {
        0: {
            items: 2
        },
        500: {
            items: 4
        },
        1000: {
            items: 6
        }
    }
})
let portfoliotabs = document.querySelectorAll('.portfoliotab');
let portfoliocontent = document.querySelectorAll('.portfoliocontent-item');
for (let i = 0; i < portfoliotabs.length; i++) {
    portfoliotabs[i].addEventListener('click', () => tabClick(i));
}
function tabClick(currentTab) {
    removeActive();
    portfoliotabs[currentTab].classList.add('active');
    portfoliocontent[currentTab].classList.add('active');
    console.log(currentTab);
}
function removeActive() {
    for (let i = 0; i < portfoliotabs.length; i++) {
        portfoliotabs[i].classList.remove('active');
        portfoliocontent[i].classList.remove('active');
    }
}